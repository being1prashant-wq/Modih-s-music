package com.example.offlinemusic.data

import com.example.offlinemusic.data.model.YoutubeVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Uses official YouTube Data API v3 for search + related videos.
 * Get a free API key from: https://console.cloud.google.com/
 * Enable "YouTube Data API v3"
 *
 * IMPORTANT: Replace YOUR_API_KEY_HERE with your real key before running.
 */
class YoutubeRepository {

    // ←←←  YAHAN APNI YOUTUBE DATA API KEY PAO  ←←←
    private val API_KEY = "AIzaSyB_RzIMzSy-6uvpxPJD_KePlxH4tmM9WcY"

    private val client = OkHttpClient()

    suspend fun searchVideos(query: String, maxResults: Int = 15): List<YoutubeVideo> =
        withContext(Dispatchers.IO) {
            if (API_KEY == "YOUR_API_KEY_HERE" || API_KEY.isBlank()) {
                return@withContext emptyList()
            }
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url =
                    "https://www.googleapis.com/youtube/v3/search" +
                            "?part=snippet" +
                            "&q=$encoded" +
                            "&type=video" +
                            "&maxResults=$maxResults" +
                            "&key=$API_KEY"

                parseSearchResponse(url)
            } catch (e: Exception) {
                e.printStackTrace()
                emptyList()
            }
        }

    /**
     * Official related videos using relatedToVideoId
     */
    suspend fun getRelatedVideos(videoId: String, maxResults: Int = 15): List<YoutubeVideo> =
        withContext(Dispatchers.IO) {
            if (API_KEY == "YOUR_API_KEY_HERE" || API_KEY.isBlank()) {
                return@withContext emptyList()
            }
            try {
                val url =
                    "https://www.googleapis.com/youtube/v3/search" +
                            "?part=snippet" +
                            "&relatedToVideoId=$videoId" +
                            "&type=video" +
                            "&maxResults=$maxResults" +
                            "&key=$API_KEY"

                parseSearchResponse(url)
            } catch (e: Exception) {
                e.printStackTrace()
                emptyList()
            }
        }

    private fun parseSearchResponse(url: String): List<YoutubeVideo> {
        val request = Request.Builder().url(url).get().build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: return emptyList()

        val json = JSONObject(body)
        if (json.has("error")) return emptyList()

        val items = json.optJSONArray("items") ?: return emptyList()
        val list = mutableListOf<YoutubeVideo>()

        for (i in 0 until items.length()) {
            val item = items.getJSONObject(i)
            val idObj = item.optJSONObject("id") ?: continue
            val videoId = idObj.optString("videoId", "")
            if (videoId.isBlank()) continue

            val snippet = item.getJSONObject("snippet")
            val thumbnails = snippet.getJSONObject("thumbnails")
            val thumb = when {
                thumbnails.has("medium") -> thumbnails.getJSONObject("medium").getString("url")
                thumbnails.has("high") -> thumbnails.getJSONObject("high").getString("url")
                else -> thumbnails.getJSONObject("default").getString("url")
            }

            list.add(
                YoutubeVideo(
                    videoId = videoId,
                    title = snippet.getString("title"),
                    channelTitle = snippet.getString("channelTitle"),
                    thumbnailUrl = thumb,
                    description = snippet.optString("description", "")
                )
            )
        }
        return list
    }

    /**
     * Simple heuristic: treat as music/song if title has common music keywords
     */
    fun isLikelyMusic(video: YoutubeVideo): Boolean {
        val t = video.title.lowercase()
        return t.contains("official audio") ||
                t.contains("lyrics") ||
                t.contains("lyric video") ||
                t.contains("audio") ||
                t.contains("song") ||
                t.contains("music") ||
                t.contains("full song") ||
                t.contains("official music") ||
                t.contains("slowed") ||
                t.contains("reverb") ||
                t.contains("lofi") ||
                t.contains("cover") ||
                t.contains("remix")
    }
}
