package com.example.offlinemusic

import android.app.Application

class OfflineMusicApp : Application()
