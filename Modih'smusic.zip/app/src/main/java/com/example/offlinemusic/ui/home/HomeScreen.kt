package com.example.offlinemusic.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.ui.components.SongCard
import com.example.offlinemusic.ui.components.SongListItem
import com.example.offlinemusic.ui.theme.AccentPurple
import com.example.offlinemusic.ui.theme.DarkBg
import com.example.offlinemusic.ui.theme.DarkBg2
import com.example.offlinemusic.ui.theme.TextPrimary
import com.example.offlinemusic.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    onPlaySong: (Song, List<Song>) -> Unit,
    onViewAllSongs: () -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val loading by viewModel.loading.collectAsState()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsState()
    val yourSongs by viewModel.yourSongs.collectAsState()
    val mostPlayed by viewModel.mostPlayed.collectAsState()
    val allSongs by viewModel.allSongs.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(DarkBg2, DarkBg, Color(0xFF0A0A1A))
                )
            )
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = AccentPurple
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 100.dp)
            ) {
                item {
                    Text(
                        text = "Home",
                        color = TextPrimary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
                    )
                }

                // Recently Played - gentle horizontal like YT Music
                item {
                    SectionTitle("Recently Played")
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(recentlyPlayed) { song ->
                            SongCard(
                                song = song,
                                onClick = {
                                    viewModel.recordPlay(song)
                                    onPlaySong(song, allSongs)
                                },
                                width = 130
                            )
                        }
                    }
                }

                item { Spacer(Modifier.height(28.dp)) }

                // Your Songs + View All
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Your Songs",
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        TextButton(onClick = onViewAllSongs) {
                            Text("View All Songs", color = AccentPurple, fontSize = 13.sp)
                        }
                    }
                }
                item {
                    Column {
                        yourSongs.take(5).forEach { song ->
                            SongListItem(
                                song = song,
                                onClick = {
                                    viewModel.recordPlay(song)
                                    onPlaySong(song, allSongs)
                                }
                            )
                        }
                    }
                }

                item { Spacer(Modifier.height(24.dp)) }

                // Most Times Played
                item {
                    SectionTitle("Most Times Played")
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(mostPlayed) { song ->
                            SongCard(
                                song = song,
                                onClick = {
                                    viewModel.recordPlay(song)
                                    onPlaySong(song, allSongs)
                                },
                                width = 130
                            )
                        }
                    }
                }

                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        color = TextPrimary,
        fontSize = 20.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}
