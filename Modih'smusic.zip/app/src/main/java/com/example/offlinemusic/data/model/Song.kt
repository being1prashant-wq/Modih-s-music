package com.example.offlinemusic.data.model

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val genre: String = "",
    val dateAdded: Long = 0L,
    val contentUri: Uri,
    val albumArtUri: Uri? = null,
    val path: String = "",
    val mood: Mood = Mood.UNKNOWN
) {
    enum class Mood {
        SAD, HAPPY, ENERGETIC, ROMANTIC, CHILL, UNKNOWN
    }
}
