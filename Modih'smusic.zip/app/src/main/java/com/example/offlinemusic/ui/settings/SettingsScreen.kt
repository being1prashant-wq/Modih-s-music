package com.example.offlinemusic.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.offlinemusic.ui.components.GlassCard
import com.example.offlinemusic.ui.theme.DarkBg
import com.example.offlinemusic.ui.theme.DarkBg2
import com.example.offlinemusic.ui.theme.TextMuted
import com.example.offlinemusic.ui.theme.TextPrimary

@Composable
fun SettingsScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DarkBg2, DarkBg)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Text(
                text = "Settings",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(24.dp))

            listOf(
                "Theme" to "Glass Dark (default)",
                "Audio Focus" to "Enabled",
                "Notifications" to "On",
                "Scan Library" to "Tap to rescan",
                "About" to "Offline Music Glass v2.0"
            ).forEach { (title, subtitle) ->
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    cornerRadius = 16.dp
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(title, color = TextPrimary, fontSize = 16.sp)
                        Text(subtitle, color = TextMuted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
