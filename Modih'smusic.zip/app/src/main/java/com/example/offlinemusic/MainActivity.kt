package com.example.offlinemusic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.offlinemusic.data.MusicRepository
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.media.PlayerController
import com.example.offlinemusic.ui.components.MiniPlayer
import com.example.offlinemusic.ui.equalizer.EqualizerScreen
import com.example.offlinemusic.ui.home.HomeScreen
import com.example.offlinemusic.ui.home.HomeViewModel
import com.example.offlinemusic.ui.library.LibraryScreen
import com.example.offlinemusic.ui.online.OnlineMusicScreen
import com.example.offlinemusic.ui.player.PlayerScreen
import com.example.offlinemusic.ui.settings.SettingsScreen
import com.example.offlinemusic.ui.theme.AccentPurple
import com.example.offlinemusic.ui.theme.OfflineMusicGlassTheme
import com.example.offlinemusic.ui.theme.TextMuted
import com.example.offlinemusic.ui.theme.TextPrimary
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import android.Manifest
import android.os.Build
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.ui.Alignment

class MainActivity : ComponentActivity() {
    private lateinit var playerController: PlayerController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        playerController = PlayerController(this)
        playerController.connect()

        setContent {
            OfflineMusicGlassTheme {
                MainApp(playerController)
            }
        }
    }

    override fun onDestroy() {
        playerController.disconnect()
        super.onDestroy()
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun MainApp(playerController: PlayerController) {
    val context = LocalContext.current
    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val permissionState = rememberPermissionState(permission)

    if (!permissionState.status.isGranted) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Audio permission required", color = TextPrimary)
                Button(onClick = { permissionState.launchPermissionRequest() }) {
                    Text("Grant Permission")
                }
            }
        }
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var showFullPlayer by remember { mutableStateOf(false) }
    var relatedSongs by remember { mutableStateOf<List<Song>>(emptyList()) }

    val currentSong by playerController.currentSong.collectAsState()
    val isPlaying by playerController.isPlaying.collectAsState()
    val homeVm: HomeViewModel = viewModel()
    val repo = remember { MusicRepository(context) }

    val tabs = listOf(
        TabItem("Home", Icons.Default.Home),
        TabItem("Online", Icons.Default.Public),
        TabItem("EQ", Icons.Default.Equalizer),
        TabItem("Settings", Icons.Default.Settings),
        TabItem("Library", Icons.Default.LibraryMusic)
    )

    if (showFullPlayer && currentSong != null) {
        PlayerScreen(
            playerController = playerController,
            relatedSongs = relatedSongs,
            onClose = { showFullPlayer = false },
            onPlayRelated = { song ->
                val newRelated = repo.getRelatedSongs(song)
                relatedSongs = newRelated
                playerController.playSong(song, newRelated.ifEmpty { listOf(song) })
                homeVm.recordPlay(song)
            }
        )
        return
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            Column {
                currentSong?.let { song ->
                    MiniPlayer(
                        song = song,
                        isPlaying = isPlaying,
                        onTogglePlay = { playerController.togglePlayPause() },
                        onNext = { playerController.seekToNext() },
                        onExpand = { showFullPlayer = true }
                    )
                }
                NavigationBar(
                    containerColor = Color(0xEE0D0D0D),
                    tonalElevation = 0.dp
                ) {
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = {
                                Icon(
                                    tab.icon,
                                    contentDescription = tab.label,
                                    tint = if (selectedTab == index) AccentPurple else TextMuted
                                )
                            },
                            label = {
                                Text(
                                    tab.label,
                                    color = if (selectedTab == index) AccentPurple else TextMuted
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color.Transparent
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> HomeScreen(
                    onPlaySong = { song, all ->
                        val related = repo.getRelatedSongs(song)
                        relatedSongs = related
                        playerController.playSong(song, related.ifEmpty { all })
                        homeVm.recordPlay(song)
                        showFullPlayer = true
                    },
                    onViewAllSongs = { selectedTab = 4 }
                )
                1 -> OnlineMusicScreen()
                2 -> EqualizerScreen()
                3 -> SettingsScreen()
                4 -> LibraryScreen(
                    onPlaySong = { song, list ->
                        val related = repo.getRelatedSongs(song)
                        relatedSongs = related
                        playerController.playSong(song, related.ifEmpty { list })
                        homeVm.recordPlay(song)
                        showFullPlayer = true
                    }
                )
            }
        }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)
