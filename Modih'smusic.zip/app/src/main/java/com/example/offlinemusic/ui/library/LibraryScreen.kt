package com.example.offlinemusic.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.ui.components.GlassCard
import com.example.offlinemusic.ui.components.SongListItem
import com.example.offlinemusic.ui.home.HomeViewModel
import com.example.offlinemusic.ui.theme.AccentPurple
import com.example.offlinemusic.ui.theme.DarkBg
import com.example.offlinemusic.ui.theme.DarkBg2
import com.example.offlinemusic.ui.theme.TextMuted
import com.example.offlinemusic.ui.theme.TextPrimary

@Composable
fun LibraryScreen(
    onPlaySong: (Song, List<Song>) -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val allSongs by viewModel.allSongs.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Songs", "Artists", "Stream YouTube")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DarkBg2, DarkBg)))
    ) {
        Column(Modifier.fillMaxSize()) {
            Text(
                text = "Library",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            )

            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                edgePadding = 16.dp,
                divider = {}
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                title,
                                color = if (selectedTab == index) AccentPurple else TextMuted,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            when (selectedTab) {
                0 -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 100.dp)) {
                        items(allSongs) { song ->
                            SongListItem(song = song, onClick = {
                                viewModel.recordPlay(song)
                                onPlaySong(song, allSongs)
                            })
                        }
                    }
                }
                1 -> {
                    val artists = allSongs.groupBy { it.artist }.toList()
                    LazyColumn(contentPadding = PaddingValues(bottom = 100.dp)) {
                        items(artists) { (artist, songs) ->
                            ArtistRow(artist = artist, count = songs.size) {
                                // play first song of artist for simplicity
                                songs.firstOrNull()?.let {
                                    viewModel.recordPlay(it)
                                    onPlaySong(it, songs)
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Stream link from YouTube option
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            cornerRadius = 24.dp
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    Icons.Default.Link,
                                    contentDescription = null,
                                    tint = AccentPurple,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(Modifier.height(16.dp))
                                Text(
                                    "Stream from YouTube",
                                    color = TextPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "Paste YouTube link to stream music\n(Coming soon / Under Progress)",
                                    color = TextMuted,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArtistRow(artist: String, count: Int, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlassCard(modifier = Modifier.size(48.dp), cornerRadius = 24.dp) {
            Icon(
                Icons.Default.Person,
                null,
                tint = TextPrimary,
                modifier = Modifier.align(Alignment.Center)
            )
        }
        Spacer(Modifier.padding(12.dp))
        Column {
            Text(artist, color = TextPrimary, fontSize = 16.sp)
            Text("$count songs", color = TextMuted, fontSize = 12.sp)
        }
    }
}
