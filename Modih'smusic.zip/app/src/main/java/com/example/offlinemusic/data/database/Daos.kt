package com.example.offlinemusic.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT songId FROM favorites")
    fun getAllFavoriteIds(): Flow<List<Long>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(fav: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE songId = :songId")
    suspend fun removeFavorite(songId: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE songId = :songId)")
    suspend fun isFavorite(songId: Long): Boolean
}

@Dao
interface PlayStatDao {
    @Query("SELECT * FROM play_stats")
    fun getAllStats(): Flow<List<PlayStatEntity>>

    @Query("SELECT * FROM play_stats WHERE songId = :songId")
    suspend fun getStat(songId: Long): PlayStatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stat: PlayStatEntity)

    @Query("SELECT * FROM play_stats ORDER BY playCount DESC LIMIT :limit")
    suspend fun getMostPlayed(limit: Int): List<PlayStatEntity>

    @Query("SELECT * FROM play_stats ORDER BY lastPlayed DESC LIMIT :limit")
    suspend fun getRecentlyPlayed(limit: Int): List<PlayStatEntity>
}
