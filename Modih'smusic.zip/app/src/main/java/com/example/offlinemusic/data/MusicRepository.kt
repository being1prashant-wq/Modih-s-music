package com.example.offlinemusic.data

import android.content.Context
import com.example.offlinemusic.data.database.AppDatabase
import com.example.offlinemusic.data.database.FavoriteEntity
import com.example.offlinemusic.data.database.PlayStatEntity
import com.example.offlinemusic.data.model.Song
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MusicRepository(context: Context) {
    private val mediaStore = MediaStoreRepository(context)
    private val db = AppDatabase.get(context)
    private val favDao = db.favoriteDao()
    private val statsDao = db.playStatDao()

    @Volatile private var cachedSongs: List<Song> = emptyList()

    suspend fun loadSongs(forceRefresh: Boolean = false): List<Song> {
        if (cachedSongs.isEmpty() || forceRefresh) {
            cachedSongs = mediaStore.loadAllSongs()
        }
        return cachedSongs
    }

    fun getFavoriteIds(): Flow<List<Long>> = favDao.getAllFavoriteIds()

    suspend fun toggleFavorite(songId: Long) {
        if (favDao.isFavorite(songId)) {
            favDao.removeFavorite(songId)
        } else {
            favDao.addFavorite(FavoriteEntity(songId))
        }
    }

    suspend fun isFavorite(songId: Long): Boolean = favDao.isFavorite(songId)

    suspend fun recordPlay(songId: Long) {
        val existing = statsDao.getStat(songId)
        val newCount = (existing?.playCount ?: 0) + 1
        statsDao.upsert(
            PlayStatEntity(
                songId = songId,
                playCount = newCount,
                lastPlayed = System.currentTimeMillis()
            )
        )
    }

    suspend fun getRecentlyPlayedSongs(limit: Int = 10): List<Song> {
        val stats = statsDao.getRecentlyPlayed(limit)
        val songMap = cachedSongs.associateBy { it.id }
        return stats.mapNotNull { songMap[it.songId] }
    }

    suspend fun getMostPlayedSongs(limit: Int = 10): List<Song> {
        val stats = statsDao.getMostPlayed(limit)
        val songMap = cachedSongs.associateBy { it.id }
        return stats.mapNotNull { songMap[it.songId] }
    }

    fun getSongsByMood(mood: Song.Mood, excludeId: Long? = null): List<Song> {
        return cachedSongs.filter { it.mood == mood && it.id != excludeId }
    }

    fun getRelatedSongs(current: Song, limit: Int = 30): List<Song> {
        // Prefer same mood, then same artist/album, then others
        val sameMood = cachedSongs.filter { it.mood == current.mood && it.id != current.id }
        val sameArtist = cachedSongs.filter { it.artist == current.artist && it.id != current.id && it.mood != current.mood }
        val sameAlbum = cachedSongs.filter { it.album == current.album && it.id != current.id }
        val rest = cachedSongs.filter { it.id != current.id }

        val combined = (sameMood + sameArtist + sameAlbum + rest).distinctBy { it.id }
        return combined.take(limit)
    }
}
