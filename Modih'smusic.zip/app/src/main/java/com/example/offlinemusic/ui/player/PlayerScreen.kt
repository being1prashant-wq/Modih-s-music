package com.example.offlinemusic.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.offlinemusic.data.model.Song
import com.example.offlinemusic.media.PlayerController
import com.example.offlinemusic.ui.components.GlassCard
import com.example.offlinemusic.ui.components.SongListItem
import com.example.offlinemusic.ui.theme.AccentPurple
import com.example.offlinemusic.ui.theme.DarkBg
import com.example.offlinemusic.ui.theme.TextMuted
import com.example.offlinemusic.ui.theme.TextPrimary
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(
    playerController: PlayerController,
    relatedSongs: List<Song>,
    onClose: () -> Unit,
    onPlayRelated: (Song) -> Unit
) {
    val currentSong by playerController.currentSong.collectAsState()
    val isPlaying by playerController.isPlaying.collectAsState()
    val position by playerController.position.collectAsState()
    val duration by playerController.duration.collectAsState()

    var isFavorite by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            playerController.updatePosition()
            delay(500)
        }
    }

    val song = currentSong ?: return

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF1A0A2E),
                        DarkBg,
                        Color(0xFF0A0A1A)
                    )
                )
            )
    ) {
        // Blurred art background simulation
        if (song.albumArtUri != null) {
            AsyncImage(
                model = song.albumArtUri,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f)),
                contentScale = ContentScale.Crop,
                alpha = 0.25f
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                // Top bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.KeyboardArrowDown, null, tint = TextPrimary)
                    }
                    Text("Now Playing", color = TextMuted, fontSize = 14.sp)
                    IconButton(onClick = { isFavorite = !isFavorite }) {
                        Icon(
                            if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            null,
                            tint = if (isFavorite) AccentPurple else TextPrimary
                        )
                    }
                }
            }

            item {
                // Album art glass
                GlassCard(
                    modifier = Modifier
                        .padding(horizontal = 40.dp)
                        .fillMaxWidth()
                        .aspectRatio(1f),
                    cornerRadius = 28.dp,
                    strong = true
                ) {
                    if (song.albumArtUri != null) {
                        AsyncImage(
                            model = song.albumArtUri,
                            contentDescription = song.title,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(28.dp)),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            Icons.Default.MusicNote,
                            null,
                            tint = TextPrimary,
                            modifier = Modifier
                                .size(80.dp)
                                .align(Alignment.Center)
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(28.dp)) }

            item {
                Text(
                    text = song.title,
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )
                Text(
                    text = song.artist,
                    color = TextMuted,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
                // Mood badge
                Text(
                    text = "Mood: ${song.mood.name.lowercase().replaceFirstChar { it.uppercase() }}",
                    color = AccentPurple,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            item { Spacer(Modifier.height(20.dp)) }

            // Progress
            item {
                Column(modifier = Modifier.padding(horizontal = 28.dp)) {
                    Slider(
                        value = if (duration > 0) position.toFloat() / duration else 0f,
                        onValueChange = { playerController.seekTo((it * duration).toLong()) },
                        colors = SliderDefaults.colors(
                            thumbColor = AccentPurple,
                            activeTrackColor = AccentPurple,
                            inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatTime(position), color = TextMuted, fontSize = 12.sp)
                        Text(formatTime(duration), color = TextMuted, fontSize = 12.sp)
                    }
                }
            }

            item { Spacer(Modifier.height(12.dp)) }

            // Controls
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        shuffle = !shuffle
                        playerController.setShuffle(shuffle)
                    }) {
                        Icon(
                            Icons.Default.Shuffle,
                            null,
                            tint = if (shuffle) AccentPurple else TextPrimary
                        )
                    }
                    IconButton(onClick = { playerController.seekToPrevious() }) {
                        Icon(Icons.Default.SkipPrevious, null, tint = TextPrimary, modifier = Modifier.size(36.dp))
                    }
                    GlassCard(
                        modifier = Modifier.size(72.dp),
                        cornerRadius = 36.dp,
                        strong = true
                    ) {
                        IconButton(
                            onClick = { playerController.togglePlayPause() },
                            modifier = Modifier.align(Alignment.Center)
                        ) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                null,
                                tint = TextPrimary,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }
                    IconButton(onClick = { playerController.seekToNext() }) {
                        Icon(Icons.Default.SkipNext, null, tint = TextPrimary, modifier = Modifier.size(36.dp))
                    }
                    IconButton(onClick = {
                        playerController.setRepeatMode(
                            if (androidx.media3.common.Player.REPEAT_MODE_ONE == 1) 0 else 1
                        )
                    }) {
                        Icon(Icons.Default.Repeat, null, tint = TextPrimary)
                    }
                }
            }

            item { Spacer(Modifier.height(32.dp)) }

            // Suggestions based on mood
            item {
                Text(
                    text = "Suggested for you • ${song.mood.name.lowercase()}",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                )
                Text(
                    text = "Based on current mood – all songs shuffled by similarity",
                    color = TextMuted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
            }

            items(relatedSongs) { related ->
                SongListItem(
                    song = related,
                    onClick = { onPlayRelated(related) }
                )
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).toInt()
    val min = totalSec / 60
    val sec = totalSec % 60
    return "%d:%02d".format(min, sec)
}
