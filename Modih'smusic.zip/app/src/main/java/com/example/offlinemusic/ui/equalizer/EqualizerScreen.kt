package com.example.offlinemusic.ui.equalizer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.offlinemusic.ui.components.GlassCard
import com.example.offlinemusic.ui.theme.AccentPurple
import com.example.offlinemusic.ui.theme.DarkBg
import com.example.offlinemusic.ui.theme.DarkBg2
import com.example.offlinemusic.ui.theme.TextMuted
import com.example.offlinemusic.ui.theme.TextPrimary

@Composable
fun EqualizerScreen() {
    val bands = listOf("60Hz", "230Hz", "910Hz", "3.6k", "14k")
    val values = bands.map { remember { mutableFloatStateOf(0.5f) } }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DarkBg2, DarkBg)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Text(
                text = "Equalizer",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(24.dp))

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 24.dp
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Visual EQ (Demo)", color = TextMuted, fontSize = 13.sp)
                    Spacer(Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        bands.forEachIndexed { index, label ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Slider(
                                    value = values[index].floatValue,
                                    onValueChange = { values[index].floatValue = it },
                                    valueRange = 0f..1f,
                                    modifier = Modifier
                                        .height(160.dp)
                                        .width(40.dp),
                                    colors = SliderDefaults.colors(
                                        thumbColor = AccentPurple,
                                        activeTrackColor = AccentPurple
                                    )
                                )
                                Text(label, color = TextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Note: Real system EQ needs AudioEffect API integration",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
