package com.example.offlinemusic.ui.theme

import androidx.compose.ui.graphics.Color

val GlassWhite = Color(0x33FFFFFF)
val GlassWhiteStrong = Color(0x55FFFFFF)
val GlassBorder = Color(0x44FFFFFF)
val AccentPurple = Color(0xFFBB86FC)
val AccentPink = Color(0xFFFF79C6)
val AccentBlue = Color(0xFF82B1FF)
val DarkBg = Color(0xFF0D0D0D)
val DarkBg2 = Color(0xFF1A1A2E)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xCCFFFFFF)
val TextMuted = Color(0x88FFFFFF)
