# Modih Music

A native Android offline music player with **iMusic-style transparent glass (glassmorphism) UI**.

Built completely fresh based on new requirements (not based on previous project).

## Features

### UI
- Full glassmorphism / frosted glass look (translucent cards, soft borders, dark gradient backgrounds)
- Bottom navigation:
  1. **Home**
  2. **Online Music** → shows “Under Progress” (does not open real content)
  3. **Equalizer** (visual demo EQ)
  4. **Settings**
  5. **Library** (Songs / Artists / Stream from YouTube)

### Home Screen
- **Recently Played** – horizontal gentle cards (YouTube Music style), 5–10 songs
- **Your Songs** – list of some songs + **View All Songs** button on the side
- **Most Times Played** – horizontal cards

### Player (iMusic-like)
- Large artwork with glass frame
- Progress slider, shuffle / previous / play-pause / next / repeat
- Favorite button
- **Mood-based suggestions** below the player:
  - Detects mood from title/artist/genre keywords (sad, chakwa/energetic, romantic, chill, happy…)
  - Suggests similar mood songs first, then same artist/album, then rest
  - All related songs appear in the scrollable list under the player

### Library
- Songs tab
- Artists tab
- Stream YouTube option (placeholder / under progress)

### Technical
- Kotlin + Jetpack Compose + Material3
- Media3 (ExoPlayer) + MediaSession for background playback & notification
- Room for favorites + play stats
- MediaStore scanning
- Coil for artwork
- Local mood detection (no network / no AI)

## How to open

1. Open the `OfflineMusicNew` folder in Android Studio (Koala / Ladybug or newer).
2. Let Gradle sync.
3. Run on a real device or emulator with local music files.
4. Grant audio permission when asked.

## Notes

- Launcher icons are placeholders – use Android Studio Image Asset Studio to replace.
- Equalizer is visual only (real system EQ needs AudioEffect).
- Online Music & YouTube stream are marked “Under Progress” as requested.
- Mood detection uses simple keyword matching on title/artist/genre (works best with tagged files).

Enjoy the glass UI!

## Online Music (YouTube)

- Search uses **official YouTube Data API v3**
- Playback uses **official YouTube IFrame Player** inside the app (YouTube app does NOT open)
- Ads may appear (this is required by YouTube terms)

### Setup API Key
1. Go to https://console.cloud.google.com/
2. Create a project → Enable **YouTube Data API v3**
3. Create an API Key
4. Open `app/src/main/java/com/example/offlinemusic/data/YoutubeRepository.kt`
5. Replace `YOUR_API_KEY_HERE` with your real key

Without a valid key, search will return empty results.
